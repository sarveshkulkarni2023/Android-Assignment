plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}

android {
    namespace = "com.example.sample_app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.sample_app"
        minSdk = 22
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx) // Core KTX library
    implementation(libs.androidx.appcompat) // AppCompat library for backward compatibility
    implementation(libs.material) // Material design components
    implementation(libs.androidx.activity) // Activity KTX library
    implementation(libs.androidx.constraintlayout) // ConstraintLayout
    testImplementation(libs.junit) // Unit testing framework
    androidTestImplementation(libs.androidx.junit) // JUnit for Android testing
    androidTestImplementation(libs.androidx.espresso.core) // Espresso for UI testing
}
