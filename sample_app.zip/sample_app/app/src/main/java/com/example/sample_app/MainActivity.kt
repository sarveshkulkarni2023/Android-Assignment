package com.example.sample_app

import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Declare UI elements
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Ensure this layout file exists

        // Connect UI elements to layout
        nameEditText = findViewById(R.id.editTextName)
        emailEditText = findViewById(R.id.editTextEmail)
        passwordEditText = findViewById(R.id.editTextPassword)
        phoneEditText = findViewById(R.id.editTextContact)
        addressEditText = findViewById(R.id.editTextAddress)

        registerButton = findViewById(R.id.registerButton)
        imageView = findViewById(R.id.imageView)

        registerButton.setOnClickListener {
            validateInputs()
        }

        imageView.setOnClickListener {
            Toast.makeText(this, "Image clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validateInputs() {
        // Validation logic...
    }
}
