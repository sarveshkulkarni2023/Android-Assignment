package com.example.sample_app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val buttonSendToThirdActivity: Button = findViewById(R.id.buttonSendToThirdActivity)

        // Retrieve data from the intent
        val intent = intent
        val string1 = intent.getStringExtra("string1")
        val string2 = intent.getStringExtra("string2")
        val string3 = intent.getStringExtra("string3")
        val string4 = intent.getStringExtra("string4")
        val string5 = intent.getStringExtra("string5")
        val booleanValue = intent.getBooleanExtra("booleanValue", false)
        val intValue = intent.getIntExtra("intValue", 0)
        val floatValue = intent.getFloatExtra("floatValue", 0f)

        val resultText = """
            String 1: $string1
            String 2: $string2
            String 3: $string3
            String 4: $string4
            String 5: $string5
            Boolean Value: $booleanValue
            Integer Value: $intValue
            Float Value: $floatValue
        """.trimIndent()

        resultTextView.text = resultText
        Log.i("SECOND_ACTIVITY", resultText)

        buttonSendToThirdActivity.setOnClickListener {
            val finalData = "Final Data: $string1, $string2, $string3, $string4, $string5, Boolean: $booleanValue, Int: $intValue, Float: $floatValue"
            val thirdActivityIntent = Intent(this, ThirdActivity::class.java).apply {
                putExtra("finalData", finalData)
            }
            startActivity(thirdActivityIntent)
        }
    }
}
